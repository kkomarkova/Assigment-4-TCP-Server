﻿using System;
using System.Collections.Generic;
using System.Text;
using Assignment1ClassLibrary;

namespace Asigment4TCPServer
{
    static class BookList
    {
        public static List<Book> Books = new List<Book>()
        {
            new Book("1234567890123","John","Titanic",67),
            new Book("1234567890123","Peter","New",67),
            new Book("1234567890123","Peter","New",67)
        };
    }
}
